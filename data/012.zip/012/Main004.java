import java.io.ObjectInputFilter.Status;
import java.math.BigInteger;
import java.time.DayOfWeek;
import java.util.Random;
import java.util.Scanner;

public class Main004 {
  public static void main(String[] args) {
    // int value = 1;

    // if (value == 1) {
    // System.out.println("раз");
    // } else {
    // if (value == 2) {
    // System.out.println("два");
    // } else {
    // if (value == 3) {
    // System.out.println("три");
    // } else {
    // if (value == 4) {
    // System.out.println("четыре");
    // } else {
    // System.out.println("что-то другое");
    // }
    // }
    // }
    // }
    // value = 6;
    // switch (value) {
    // case 1:
    // System.out.println("раз");
    // break;

    // case 2:
    // System.out.println("два");
    // break;

    // case 3:
    // System.out.println("три");
    // break;

    // case 4:
    // case 5:
    // case 6:
    // case 7:
    // System.out.println("четыре");
    // break;

    // default:
    // System.out.println("что-то другое");
    // break;
    // }

    // int a = 1;
    // int b = 1;

    // int max;
    // if (a > b) {
    // System.out.println("Урааааа");
    // } else {
    // max = b;
    // }

    // max = a > b ? a : b;
    // int userId = 0;
    // userId = userId == 1 ? 0 : 1;
    // // type var = bool expression1 ? type expression2 : type expression3;
    // // max = (a > b) then a else b;

    // int a = new Random().nextInt(100, 1000);
    // int x = a / 100;
    // int y = a % 100 / 10;
    // int z = a % 10;

    // System.out.printf("%d %d %d\n", x, y, z);

    // if (x >= y && x >= z) {
    // System.out.println("max = " + x);
    // } else if (z >= y) {
    // System.out.println("max = " + z);
    // } else {
    // System.out.println("max = " + y);
    // }

    // int max = x;

    // if (y > max)
    // max = y;

    // if (z > max)
    // max = z;

    // System.out.println(max);
    int a = new Random().nextInt(100, 100000000);
    System.out.println(a);
    int max = -1;

    while (a != 0) {
      int o = a % 10;
      a = a / 10;
      System.out.println("o = " + o);
      System.out.println("a = " + a);
      if (o > max)
        max = o;
    }

    System.out.println(max);
  }

}