import java.util.Scanner;

public class Main003 {
  public static void main(String[] args) {

    int a = getInt("value a", 1, 3);
    int b = getInt("value b", 10, 20);
  }

  static Scanner sc = new Scanner(System.in);

  static int getInt(String text, int min, int max) {
    int value = 0; //

    while (!(value >= min && value <= max)) {
      System.out.printf("%s [%d; %d]: ", text, min, max);
      if (sc.hasNextInt()) {
        value = sc.nextInt();
      } else {
        sc.next();
      }
    }
    return value;
  }
}
