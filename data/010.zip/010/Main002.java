public class Main002 {
  public static void main(String[] args) {
    boolean userId = true; // false
    // true = первый игрок
    // false = второй игрок

    // if (userId == true) {
    // userId = false;
    // } else {
    // userId = true;
    // }
    userId = !userId;

    if (userId) {
      System.out.println("Ход Васи");
    } else {
      System.out.println("Ход Маши");
    }

    userId = !userId;
    userId = userId ? false : true;
    // int userId = 0; //
    // // 0 = первый игрок
    // // 1 = второй игрок

    // if (userId == 0) {
    // userId = 1;
    // } else {
    // userId = 0;
    // }
  }
}
