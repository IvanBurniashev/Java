/**
 * Main001
 */
public class Main001 {
  public static void main(String[] args) {
    // // 1
    // if (condition) {
    // // оператор 1
    // } else {
    // // оператор 2
    // }

    // // 2
    // if (condition) {
    // // оператор 1
    // }
    // // оператор 2

    // // 3
    // if (condition) {

    // } else {
    // // оператор 1
    // }
    // // оператор 2

    // if (condition 1) {
    // if (condition 2) {
    // if (condition 3) {
    // // оператор 3
    // } else {
    // // оператор 2
    // }
    // } else {
    // if (condition 4) {
    // // оператор 4
    // } else {
    // // оператор 5
    // }
    // }
    // } else {
    // // оператор 1
    // }

    // if (condition 1) {
    // // оператор 1
    // if (condition 2) {
    // // оператор 2
    // if (condition 3) {
    // // оператор 3
    // if (condition 4) {
    // // оператор 4
    // }
    // }
    // }
    // }

    // if (condition 1) {
    // // оператор 1
    // }
    // if (condition 2) {
    // // оператор 2
    // }
    // if (condition 3) {
    // // оператор 3
    // }
    // if (condition 4) {
    // // оператор 4
    // }

    // int value = 2;

    // if (value == 1) {
    // System.out.println("один");
    // }
    // if (value == 2) {
    // System.out.println("два");
    // }
    // if (value == 3) {
    // System.out.println("три");
    // }
    // if (value == 4) {
    // System.out.println("четыре");
    // }
    int value = 2;
    switch (value) {
      case 1:
        System.out.println("один");
        return;
      case 2:
        System.out.println("два");
        return;
      case 3:
        System.out.println("три");
        return;
      case 4:
        System.out.println("четыре");
        return;
    }
  }
}
